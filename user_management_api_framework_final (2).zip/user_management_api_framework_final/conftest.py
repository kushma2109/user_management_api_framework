
import pytest, os
from common.config import load_env_config
from api.client import HTTPClient
from api.users import UsersAPI
from common.assertions import attach_req_resp

@pytest.fixture(scope='session')
def env():
    return load_env_config()

@pytest.fixture(scope='session')
def client(env):
    return HTTPClient(env['base_url'])

@pytest.fixture()
def users_api(client):
    return UsersAPI(client)

# auto-attach on failure
def pytest_runtest_makereport(item, call):
    if call.excinfo is not None and call.excinfo.typename != 'Skipped':
        # find 'resp' in fixture or locals - tests will attach manually using attach_req_resp
        pass
