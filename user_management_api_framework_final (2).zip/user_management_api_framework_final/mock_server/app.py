
from flask import Flask, request, jsonify

app = Flask(__name__)

users_db = {}
next_user_id = 1

@app.route("/api/v1/users", methods=["POST"])
def create_user():
    global next_user_id
    data = request.get_json()
    if not data or "username" not in data or "email" not in data or "password" not in data:
        return jsonify({"code": 400, "data": None, "msg": "Missing required fields"}), 400
    # simple validation
    if "@" not in data["email"]:
        return jsonify({"code": 400, "data": None, "msg": "Invalid email"}), 400
    if any(u["username"] == data["username"] for u in users_db.values()):
        return jsonify({"code": 409, "data": None, "msg": "Username already exists"}), 409
    user = {
        "id": next_user_id,
        "username": data["username"],
        "email": data["email"],
        "password": data["password"]
    }
    users_db[next_user_id] = user
    next_user_id += 1
    return jsonify({"code": 200, "data": {"id": user["id"], "username": user["username"]}, "msg": "success"})

@app.route("/api/v1/users/<int:user_id>", methods=["GET"])
def get_user(user_id):
    user = users_db.get(user_id)
    if not user:
        return jsonify({"code": 404, "data": None, "msg": "User not found"}), 404
    return jsonify({"code": 200, "data": user, "msg": "success"})

@app.route("/api/v1/users/<int:user_id>", methods=["PUT"])
def update_user_email(user_id):
    user = users_db.get(user_id)
    if not user:
        return jsonify({"code": 404, "data": None, "msg": "User not found"}), 404
    data = request.get_json()
    if not data or "email" not in data:
        return jsonify({"code": 400, "data": None, "msg": "Email is required"}), 400
    if "@" not in data["email"]:
        return jsonify({"code": 400, "data": None, "msg": "Invalid email"}), 400
    user["email"] = data["email"]
    return jsonify({"code": 200, "data": None, "msg": "success"})

@app.route("/api/v1/users/<int:user_id>", methods=["DELETE"])
def delete_user(user_id):
    if user_id not in users_db:
        return jsonify({"code": 404, "data": None, "msg": "User not found"}), 404
    del users_db[user_id]
    return jsonify({"code": 200, "data": None, "msg": "success"})

@app.route("/api/v1/users", methods=["GET"])
def list_users():
    try:
        page = int(request.args.get("page", 1))
        size = int(request.args.get("size", 10))
    except:
        return jsonify({"code": 400, "data": None, "msg": "Invalid pagination params"}), 400
    keyword = request.args.get("keyword", "")
    filtered_users = [u for u in users_db.values() if keyword.lower() in u["username"].lower()]
    total = len(filtered_users)
    start = (page - 1) * size
    end = start + size
    paged_users = filtered_users[start:end]
    data = {"total": total, "list": [{"id": u["id"], "username": u["username"]} for u in paged_users]}
    return jsonify({"code": 200, "data": data, "msg": "success"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
