
import allure
from common.utils import unique_username, unique_email
from common.assertions import attach_req_resp

@allure.feature('Users')
@allure.story('Get')
class TestGetUser:
    def test_get_user_normal(self, users_api):
        username = unique_username()
        email = unique_email()
        r = users_api.create_user(username, email, 'pwd123')
        attach_req_resp(r)
        assert r.status_code == 200
        user_id = r.json()['data']['id']
        rg = users_api.get_user(user_id)
        attach_req_resp(rg)
        assert rg.status_code == 200
        assert rg.json()['data']['username'] == username
        users_api.delete_user(user_id)

    def test_get_user_not_found(self, users_api):
        rg = users_api.get_user(99999999)
        attach_req_resp(rg)
        assert rg.status_code // 100 == 4

    def test_get_user_invalid_id(self, users_api):
        rg = users_api.client.request('GET', '/api/v1/users/abc')
        attach_req_resp(rg)
        assert rg.status_code // 100 == 4

    def test_get_user_after_delete(self, users_api):
        username = unique_username('todel')
        email = unique_email('todel')
        r = users_api.create_user(username, email, 'pwd123')
        uid = r.json()['data']['id']
        users_api.delete_user(uid)
        rg = users_api.get_user(uid)
        attach_req_resp(rg)
        assert rg.status_code // 100 == 4
