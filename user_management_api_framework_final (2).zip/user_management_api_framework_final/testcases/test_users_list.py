
import allure
from common.utils import unique_username, unique_email
from common.assertions import attach_req_resp

@allure.feature('Users')
@allure.story('List/Query')
class TestListUsers:
    def test_list_users_normal(self, users_api):
        username = unique_username('list')
        email = unique_email('list')
        r = users_api.create_user(username, email, 'pwd123')
        uid = r.json()['data']['id']

        try:
            rl = users_api.list_users(page=1, size=10, keyword=username)
            attach_req_resp(rl)
            assert rl.status_code == 200
            assert 'list' in rl.json()['data']
            ids = [u['id'] for u in rl.json()['data'].get('list', [])]
            assert uid in ids
        finally:
            users_api.delete_user(uid)

    def test_list_users_empty_page(self, users_api):
        rl = users_api.list_users(page=9999, size=50)
        attach_req_resp(rl)
        assert rl.status_code == 200
        assert isinstance(rl.json()['data'].get('list'), list)

    def test_list_users_invalid_params(self, users_api):
        r_invalid = users_api.client.request('GET', '/api/v1/users', params={'page': 'abc', 'size': '10'})
        attach_req_resp(r_invalid)
        assert r_invalid.status_code // 100 == 4

    def test_list_users_special_char_keyword(self, users_api):
        username = f"u_special_!@#{unique_username('k')}"
        email = unique_email('sp')
        r = users_api.create_user(username, email, 'pwd123')
        uid = r.json()['data']['id']
        try:
            rl = users_api.list_users(page=1, size=10, keyword='!@#')
            attach_req_resp(rl)
            assert rl.status_code == 200
        finally:
            users_api.delete_user(uid)
