
import allure
from common.utils import unique_username, unique_email
from common.assertions import attach_req_resp

@allure.feature('Users')
@allure.story('Update')
class TestUpdateUser:
    def test_update_user_email_normal(self, users_api):
        username = unique_username('upd')
        email = unique_email('orig')
        r = users_api.create_user(username, email, 'pwd123')
        attach_req_resp(r)
        assert r.status_code == 200
        user_id = r.json()['data']['id']

        try:
            new_email = unique_email('new')
            ru = users_api.update_user(user_id, {'email': new_email})
            attach_req_resp(ru)
            assert ru.status_code == 200
            rg = users_api.get_user(user_id)
            attach_req_resp(rg)
            assert rg.json()['data']['email'] == new_email
        finally:
            users_api.delete_user(user_id)

    def test_update_user_missing_email(self, users_api):
        username = unique_username('upd')
        email = unique_email('orig')
        r = users_api.create_user(username, email, 'pwd123')
        user_id = r.json()['data']['id']
        ru = users_api.update_user(user_id, {})
        attach_req_resp(ru)
        assert ru.status_code // 100 == 4
        users_api.delete_user(user_id)

    def test_update_user_invalid_email_format(self, users_api):
        username = unique_username('upd')
        email = unique_email('orig')
        r = users_api.create_user(username, email, 'pwd123')
        user_id = r.json()['data']['id']
        ru = users_api.update_user(user_id, {'email': 'not-an-email'})
        attach_req_resp(ru)
        assert ru.status_code // 100 == 4
        users_api.delete_user(user_id)

    def test_update_user_not_found(self, users_api):
        ru = users_api.update_user(99999999, {'email': unique_email('x')})
        attach_req_resp(ru)
        assert ru.status_code // 100 == 4
