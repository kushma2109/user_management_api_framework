
import allure
from common.utils import unique_username, unique_email
from common.assertions import attach_req_resp

@allure.feature('Users')
@allure.story('Create')
class TestCreateUser:
    def test_create_user_normal(self, users_api):
        username = unique_username('qa')
        email = unique_email('mail')
        r = users_api.create_user(username, email, '123456')
        attach_req_resp(r)
        assert r.status_code == 200
        body = r.json()
        assert body['code'] == 200
        assert body['data']['username'] == username

    def test_create_user_missing_password(self, users_api):
        username = unique_username('qa')
        email = unique_email('mail')
        r = users_api.client.request('POST', '/api/v1/users', json={'username': username, 'email': email})
        attach_req_resp(r)
        assert r.status_code // 100 == 4

    def test_create_user_invalid_email(self, users_api):
        username = unique_username('qa')
        r = users_api.create_user(username, 'not-an-email', '123456')
        attach_req_resp(r)
        assert r.status_code // 100 == 4

    def test_create_user_duplicate_username(self, users_api):
        username = unique_username('dup')
        email = unique_email('dup')
        r1 = users_api.create_user(username, email, '123456')
        attach_req_resp(r1)
        assert r1.status_code == 200
        r2 = users_api.create_user(username, unique_email('dup2'), '123456')
        attach_req_resp(r2)
        assert r2.status_code // 100 == 4
        # cleanup
        users_api.delete_user(r1.json()['data']['id'])
