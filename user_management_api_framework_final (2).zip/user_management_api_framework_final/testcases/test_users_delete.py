
import allure
from common.utils import unique_username, unique_email
from common.assertions import attach_req_resp

@allure.feature('Users')
@allure.story('Delete')
class TestDeleteUser:
    def test_delete_user_normal(self, users_api):
        username = unique_username('del')
        email = unique_email('del')
        r = users_api.create_user(username, email, 'pwd123')
        attach_req_resp(r)
        user_id = r.json()['data']['id']

        rd = users_api.delete_user(user_id)
        attach_req_resp(rd)
        assert rd.status_code == 200

        rg = users_api.get_user(user_id)
        attach_req_resp(rg)
        assert rg.status_code // 100 == 4

    def test_delete_user_not_found(self, users_api):
        rd = users_api.delete_user(99999999)
        attach_req_resp(rd)
        assert rd.status_code // 100 == 4

    def test_delete_user_invalid_id(self, users_api):
        rd = users_api.client.request('DELETE', '/api/v1/users/abc')
        attach_req_resp(rd)
        assert rd.status_code // 100 == 4

    def test_delete_user_double_delete(self, users_api):
        username = unique_username('ddel')
        email = unique_email('ddel')
        r = users_api.create_user(username, email, 'pwd123')
        uid = r.json()['data']['id']
        rd1 = users_api.delete_user(uid)
        attach_req_resp(rd1)
        assert rd1.status_code == 200
        rd2 = users_api.delete_user(uid)
        attach_req_resp(rd2)
        assert (rd2.status_code == 200) or (rd2.status_code // 100 == 4)
