
import allure, json
def attach_req_resp(resp):
    try:
        req = resp.request
        body = None
        if req.body is not None:
            try:
                body = req.body.decode() if hasattr(req.body, 'decode') else str(req.body)
            except Exception:
                body = str(req.body)
        resp_body = None
        try:
            resp_body = resp.json()
        except Exception:
            resp_body = resp.text
        data = {
            "request": {
                "method": req.method,
                "url": req.url,
                "body": body,
                "headers": dict(req.headers)
            },
            "response": {
                "status_code": resp.status_code,
                "body": resp_body,
                "headers": dict(resp.headers)
            }
        }
    except Exception as ex:
        data = {"error": str(ex)}
    allure.attach(json.dumps(data, default=str, indent=2), name="req_resp", attachment_type=allure.attachment_type.JSON)
