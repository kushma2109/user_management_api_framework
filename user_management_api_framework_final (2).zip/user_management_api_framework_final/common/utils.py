
import uuid
def unique_username(prefix='u'): return f"{prefix}_{uuid.uuid4().hex[:8]}"
def unique_email(prefix='t'): return f"{uuid.uuid4().hex[:8]}@{prefix}.example.com"
