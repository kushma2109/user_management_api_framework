
import os, yaml

def load_env_config():
    env = os.environ.get('ENV', 'test')
    path = os.path.join('config', f'env_{env}.yml')
    with open(path) as f:
        return yaml.safe_load(f)
