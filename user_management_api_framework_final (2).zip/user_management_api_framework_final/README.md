# 🧪 User Management API - Automated Testing Framework

### **Assignment Goal**
Design and implement an automated testing framework for a "User Management API", covering core CRUD operations with positive and negative scenarios, using Python, `pytest`, `requests`, and `allure` for reporting.

---

## 🚀 Project Overview

This project implements a **complete, modular, and extensible API automation framework** for a mock User Management REST API.

It includes:
- ✅ A **Flask-based mock API server**
- ✅ **20 automated test cases** (positive + negative)
- ✅ **Dynamic data generation** and **multi-environment support**
- ✅ **Allure test reports** with request/response logging
- ✅ **Clean modular structure** for scalability

---

## 🗂️ Project Structure

user_management_api_framework_final/
│
├── api/ # API request encapsulation layer
│ └── user_api.py
│
├── common/ # Utilities (logger, config, assertions, etc.)
│ ├── logger.py
│ ├── config_reader.py
│ └── utils.py
│
├── config/ # Environment configurations
│ ├── config_test.yaml
│ └── config_staging.yaml
│
├── mock_server/ # Flask mock server simulating real API
│ └── app.py
│
├── testcases/ # Organized test cases
│ ├── test_create_user.py
│ ├── test_get_user.py
│ ├── test_update_user.py
│ ├── test_delete_user.py
│ └── test_query_users.py
│
├── reports/ # Allure test report output directory
│
├── requirements.txt # Dependency list
└── README.md # Project documentation


---

## ⚙️ Setup Instructions

### 1️⃣ Clone or Extract Project

```bash
git clone <repo-url>
cd user_management_api_framework_final

2️⃣ Create and Activate Virtual Environment (Optional but Recommended)
python -m venv .venv
.\.venv\Scripts\Activate.ps1

3️⃣ Install Dependencies
pip install -r requirements.txt

4️⃣ Start the Mock API Server

In one terminal, run:

python mock_server/app.py

This launches the API at:

http://127.0.0.1:5000

5️⃣ Run the Tests

In another terminal (with the virtual environment activated):

pytest --alluredir=reports

Expected output:

.................... [100%]
20 passed in <1s>

6️⃣ View Allure Report

If Allure CLI is installed:

allure serve reports

he report will automatically open in your browser.

Example:


(If you don’t have Allure, install via Scoop:
irm get.scoop.sh | iex && scoop install allure)

🧩 Framework Highlights

Framework Modularity: Each API and test module is isolated and easy to extend.

Environment Switching: Controlled through YAML config files (config_test.yaml, config_staging.yaml).

Reusable Utilities:

Centralized logging (common/logger.py)

Config reader (common/config_reader.py)

Dynamic data generator (common/utils.py)

Test Case Design:

Covers normal + edge scenarios (missing parameters, invalid formats, non-existent resources)

Each test is independent and repeatable

Allure Reporting:

Rich visual reports with request/response details

Easy traceability for debugging

🧪 Example API Endpoints Tested
Method	Endpoint	Description
POST	/api/v1/users	Create a new user
GET	/api/v1/users/{id}	Get user details
PUT	/api/v1/users/{id}	Update user email
DELETE	/api/v1/users/{id}	Delete user
GET	/api/v1/users	Query users (pagination, filters)

🧾 Allure Report Summary

Total Tests: 20

Passed: 20

Failed: 0

Pass Rate: 100%

Execution Time: < 1 second

## Test Results

![Allure Report Screenshot](reports/Screenshots/image.jpg)



👩‍💻 Author

Kushma Sai Javvaji
📧 kushmasaijavvaji@gmail.com
