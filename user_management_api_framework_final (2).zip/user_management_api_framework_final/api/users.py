
from .client import HTTPClient

class UsersAPI:
    def __init__(self, client: HTTPClient):
        self.client = client

    def create_user(self, username, email, password):
        return self.client.request('POST', '/api/v1/users', json={
            'username': username, 'email': email, 'password': password
        })

    def get_user(self, user_id):
        return self.client.request('GET', f'/api/v1/users/{user_id}')

    def update_user(self, user_id, body: dict):
        return self.client.request('PUT', f'/api/v1/users/{user_id}', json=body)

    def delete_user(self, user_id):
        return self.client.request('DELETE', f'/api/v1/users/{user_id}')

    def list_users(self, page=1, size=10, keyword=None):
        params = {'page': page, 'size': size}
        if keyword:
            params['keyword'] = keyword
        return self.client.request('GET', '/api/v1/users', params=params)
