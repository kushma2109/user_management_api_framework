
import requests
from requests.adapters import HTTPAdapter, Retry
from common.logger import logger

class HTTPClient:
    def __init__(self, base_url, timeout=10):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        s = requests.Session()
        retries = Retry(total=3, backoff_factor=0.2, status_forcelist=[429,500,502,503,504])
        s.mount('http://', HTTPAdapter(max_retries=retries))
        s.mount('https://', HTTPAdapter(max_retries=retries))
        self.session = s

    def request(self, method, path, **kwargs):
        url = f"{self.base_url}{path}"
        logger.info(f"HTTP {method} {url} | payload={kwargs.get('json') or kwargs.get('params')}")
        resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        try:
            data = resp.json()
        except Exception:
            data = resp.text
        logger.info(f"RESPONSE {resp.status_code} | {data}")
        return resp
